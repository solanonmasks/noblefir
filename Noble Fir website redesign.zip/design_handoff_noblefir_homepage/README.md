# Handoff: Noble Fir Homes — Homepage Redesign

## Overview

A conversion-focused redesign of the Noble Fir Homes homepage (noblefir.ca), a family-run
general contractor / renovation company serving Metro Vancouver. The current site is a Wix
build; this redesign keeps their brand (logo, photography, dark-charcoal + warm off-white
palette, fir-green accent) and rebuilds the homepage as a premium, motion-rich single page
with lead capture as the primary goal.

**Primary conversion goal:** free-estimate form submissions.
**Secondary goal:** phone calls (778-686-0311).

## About the Design Files

The file in this bundle — `Noble Fir Homes.dc.html` — is a **design reference created in
HTML**. It is a working prototype that demonstrates the intended look, copy, layout and
motion behaviour. **It is not production code to copy directly.**

Notes on its structure, so it reads correctly:

- It is authored in a component format where the markup sits in an `<x-dc>` template and the
  behaviour sits in a `class Component extends DCLogic { … }` script at the bottom of the file.
  Treat the template as JSX-equivalent markup and the class as a React-class-equivalent.
- `{{ someName }}` are template holes filled by the values returned from `renderVals()`.
- `<sc-if value="{{ x }}">` is conditional rendering. `<sc-for list="{{ xs }}" as="x">` is a loop.
- `style-hover` / `style-focus` attributes are pseudo-state styles — implement as `:hover` / `:focus`
  in your styling layer.
- **All styling is inline by design** (a constraint of the authoring environment). In a real
  codebase, extract it into whatever your project uses — Tailwind, CSS modules, styled-components,
  vanilla CSS. Do not preserve inline styles.

**The task:** recreate this design in the target codebase's existing environment using its
established patterns, component library and styling conventions. If there is no codebase yet,
pick the most appropriate stack for a marketing site with a lead form — Next.js (App Router) +
Tailwind is a good default, since it gives SSR/SEO, image optimisation and an API route for the
form — and implement it there.

## Fidelity

**High-fidelity.** Colors, typography, spacing, copy, interaction and animation timings are all
final and intentional. Recreate the UI faithfully. Exact values are documented below.

One open item: **the typefaces are a substitution.** The live Wix site's font declarations could
not be read, so `Jost` (geometric sans, chosen to match the logo's letterforms) and `Newsreader`
(editorial serif, italic accents only) were selected. If the client supplies their real brand
fonts, swap them in — the type scale and weights below still apply.

---

## Design Tokens

### Colors

| Token | Hex | Usage |
|---|---|---|
| `ink` | `#16181A` | Primary text, top announcement bar, footer, dark buttons |
| `ink-panel` | `#1B1E1C` | Hero and projects section background (slightly green-shifted charcoal) |
| `paper` | `#FFFCFA` | Page background, light text on dark, form card (from their brand SVG fill) |
| `paper-warm` | `#F4F0EA` | Alternating section background (why-us, process, FAQ) |
| `fir` | `#2F4A3A` | Accent on light grounds: kickers, links, form CTA, sticky call bar |
| `sage` | `#A7C0AE` | Accent on dark grounds: kickers, hero CTA, progress rail, marquee dots |

Alpha inks (use over the ground stated, never lighter than these — they are at the 4.5:1 floor):

- On `paper` / `paper-warm`: body copy `rgba(22,24,26,0.65)`–`0.68`, small/muted caps `rgba(22,24,26,0.72)`, hairline borders `rgba(22,24,26,0.14)`–`0.16`, input borders `rgba(22,24,26,0.18)`.
- On `ink` / `ink-panel`: body copy `rgba(255,252,250,0.78)`, secondary `rgba(255,252,250,0.72)`, footer legal `rgba(255,252,250,0.5)`, borders `rgba(255,252,250,0.14)`–`0.35`.

Gradients (photo scrims):

- Hero: `linear-gradient(100deg, rgba(22,24,26,0.94) 0%, rgba(22,24,26,0.78) 42%, rgba(22,24,26,0.34) 100%)` over the image at `opacity: 0.5; filter: saturate(0.8) contrast(1.02)`.
- Project tiles: `linear-gradient(to top, rgba(22,24,26,0.86) 0%, rgba(22,24,26,0.1) 58%, transparent 100%)`.
- Closing CTA: `linear-gradient(to right, rgba(22,24,26,0.93), rgba(22,24,26,0.62))` over image at `opacity: 0.3`.

### Typography

Fonts: `Jost` (300/400/500/600) for everything; `Newsreader` (300, and 300 italic) for the hero's
italic line, the pull quote, the "Craftmanship" plaque and the large process numerals.

| Role | Size | Weight | Line-height | Tracking |
|---|---|---|---|---|
| H1 (hero) | `clamp(42px, 5.6vw, 82px)` | 300 | 1.02 | `-0.02em` |
| H2 (section) | `clamp(34px, 4vw, 58px)` | 300 | 1.04 | `-0.02em` |
| H2 (smaller sections) | `clamp(32px, 3.6vw, 52px)` | 300 | 1.06 | `-0.02em` |
| Pull quote (serif) | `clamp(24px, 2.8vw, 38px)` | 300 | 1.3 | `-0.01em` |
| Card H3 | `21–23px` | 400–500 | 1.2 | `-0.005em` to `-0.01em` |
| Body large | `clamp(16.5px, 1.35vw, 19px)` | 300 | 1.65–1.7 | — |
| Body | `15–16px` | 300 | 1.65–1.75 | — |
| Kicker / eyebrow | `12px` | 400 | — | `0.22em`, uppercase |
| Button / nav label | `12.5–13px` | 400 | — | `0.11em–0.14em`, uppercase |
| Micro caps | `11.5px` | 400 | — | `0.18em–0.2em`, uppercase |
| Stat numeral | `clamp(26px, 2.6vw, 34px)` | 300 | 1 | `-0.01em` |
| Process numeral (serif) | `46px` | 300 | 1 | — |

Body copy uses `font-weight: 300` throughout — this lightness is core to the look. Headings are
300 as well; only labels, `<strong>` and card titles go to 400/500. Measure is capped with
`ch` units (`max-width: 44ch`–`52ch` on paragraphs, `70ch` on FAQ answers). Long headings use
`text-wrap: balance`.

### Spacing & layout

- Content max-width `1360px`; page shell max-width `1600px`; gutter `28px`.
- Section vertical rhythm: `clamp(72px, 8vw, 128px)` (large), `clamp(64px, 7vw, 110px)` (testimonial).
- Card padding `clamp(26px, 2.4vw, 38px)`; grid gaps `clamp(18px, 2vw, 28px)` and `clamp(36px, 5vw, 80px)`.
- Anchor targets carry `scroll-margin-top: 90px` (110px on the form) to clear the sticky header.

### Radius, borders, shadow

- **Border radius: `0` everywhere.** The only rounded element in the design is the cursor-follow
  badge (`999px` pill) and the small status dots (`50%`). This is deliberate — the squared
  geometry is what separates it from a template.
- Dividers: `1px solid` at the alpha values above. Card grids are built as a `1px` gap over a
  border-colored background so the hairlines read as a single ruled grid.
- One shadow only, on the hero form card: `0 40px 90px -30px rgba(0,0,0,0.65)`. Scrolled header
  gains `0 18px 44px -28px rgba(0,0,0,0.9)`.

### Easing

- Primary: `cubic-bezier(0.19, 1, 0.22, 1)` — reveals, parallax settle, header shrink, magnetic release.
- Secondary: `cubic-bezier(0.22, 1, 0.36, 1)` — hero entrance, image hover scale, form progress bar.
- Utility: `ease` / linear for color and opacity fades.

---

## Screens / Views

Single page, twelve stacked bands, in order. Full copy is in the HTML file — exact strings should
be lifted from there.

### 1. Announcement bar
`ink` background, `paper` text, `11.5px` uppercase at `0.08em`, centered flex row, `gap: 12px 28px`,
`padding: 10px 20px`, items `white-space: nowrap`, wraps to a second line gracefully.
Three items: "Licensed & insured", "Metro Vancouver since 2014", "Free on-site estimate" (last in `sage`).

### 2. Sticky header
`position: sticky; top: 0; z-index: 60`. Background `rgba(27,30,28,0.94)` + `backdrop-filter: blur(14px)`,
bottom border `1px rgba(255,252,250,0.12)`. Inner row: `max-width 1360px`, `padding: 14px 28px`,
`min-height: 82px`, `flex-wrap: wrap`, `gap: 28px`.

- Logo left, `height: 56px`, links to `#top`.
- Nav pushed right (`margin-left: auto`), 5 links (Services, Projects, Process, Areas, FAQ),
  `13px` uppercase `0.11em`, color `rgba(255,252,250,0.82)`; on hover color `paper` **and** a
  `1px solid #A7C0AE` bottom border appears (a transparent border is reserved at rest so nothing shifts).
- Phone link `17px` in `paper`, preceded by a 7px `sage` dot with a `0 0 0 4px rgba(167,192,174,0.22)` halo.
- "Get Estimate" button: `paper` background, `ink` text, `13px 22px`, `12.5px` uppercase `0.13em`;
  hover → `sage` background.
- **Scroll behaviour:** past `scrollY > 60` the background goes to `rgba(22,24,26,0.97)`, the shadow
  fades in, inner padding animates `14px → 6px`, `min-height` `82px → 64px`, logo `56px → 42px`.
  All transitions `0.4–0.45s`.

### 3. Hero — `#top`
Two-column grid, `repeat(auto-fit, minmax(min(100%, 420px), 1fr))`, `gap: clamp(36px, 5vw, 76px)`,
`padding: clamp(56px, 7vw, 104px) 28px clamp(56px, 6vw, 96px)`, `align-items: center`,
background `ink-panel` with the full-bleed kitchen photo + the 100deg scrim above it.

Left column:
- Kicker row: 44px `sage` hairline that scales in from the left (`nfLine`, 0.8s, 0.3s delay) + "Vancouver · Richmond · Surrey · Burnaby" in `sage`.
- H1 in three masked rows — each line sits in `overflow: hidden` and lifts from `translateY(105%)` with `opacity 0 → 1` (`nfLift`, 1.1s, staggered 0.05s / 0.17s / 0.29s). Third line is Newsreader italic in `sage`.
- Intro paragraph, `max-width: 52ch`.
- CTA pair: primary `sage`/`ink` "Book my free estimate" with a `→` (hover → `paper`); secondary outlined "Call 778-686-0311" (hover → border `paper`, background `rgba(255,252,250,0.07)`). Primary is magnetic (see Interactions).
- Stat row above a `1px rgba(255,252,250,0.16)` top border, `repeat(auto-fit, minmax(128px, 1fr))`, `max-width: 620px`: **10+** Years in business · **5.0★** Homeowner rated · **7** Cities served · **100%** Warrantied work. Numerals count up on entry; the `+` and `★` are `sage` child spans that must survive the count animation.

Right column: the estimate form card (below).

### 4. Estimate form card — `#estimate`
`paper` card, `padding: clamp(26px, 2.6vw, 38px)`, the one drop shadow, enters with `nfRise` (1s, 0.14s delay).

**Two-step by default** (switchable to one step — see State):

- Header: step label (`"Step 1 of 2"` / `"Step 2 of 2"`, or `"Free estimate request"` in one-step mode) in `fir` micro caps; H2 "Get your free estimate"; reassurance line "No obligation. A real project manager replies within one business day — not a call centre."
- Progress bar: `2px` track `rgba(22,24,26,0.1)`, fill `fir`, width `50% → 100%`, `transition: width 0.45s`.
- **Step 1** — "What can we help with?" as a 2-column grid of six `1px`-bordered buttons: Kitchen, Bathroom, Full home, Condo / strata, Addition / basement, Custom build. Hover/selected → border `fir`, background `rgba(47,74,58,0.05)`. Selection echoes below as "Selected: Kitchen" in `fir`. Then a full-width `ink` "Continue" button (hover `fir`).
- **Step 2** — First name + Last name (2-col), Email, Phone, "Postal code or neighbourhood"; inputs are `1px` bordered, transparent background, `14px 15px`, focus → border `fir`, no outline. Submit: full-width `fir` "Request my estimate" (hover `ink`). Below it a text-only "← Change project type".
- Footer note with a 6px `fir` dot: "Your details stay with our team. We never sell leads to other contractors."
- **Success state** replaces the whole card body: a `52px` square `1px fir` box with a `✓`, H2 "Request received", and a line that personalises with the submitted first name and the lowercased service, plus a link to `#projects`.

Implementation note: in production, wire submit to a real endpoint (email/CRM), validate email and
phone, honeypot or captcha the form, and fire a conversion event on success. The prototype only
flips local state.

### 5. Trust marquee
`ink` band, `padding: 24px 0`, `overflow: hidden`, edge fade via
`mask-image: linear-gradient(to right, transparent, #000 9%, #000 91%, transparent)`.
Inner track is the content duplicated twice at `width: max-content`, animating
`translateX(0 → -50%)` over `42s` linear infinite; **pauses on hover**. Six claims separated by
`sage` `✦`: Locally owned, proudly Canadian / Licensed & insured / Permits & strata handled /
Workmanship warranty / Clean, respectful crews / One project manager, start to finish.
The second copy is `aria-hidden="true"`.

### 6. Services — `#services`
Header: two-column `auto-fit minmax(min(100%, 340px), 1fr)`, `align-items: end` — kicker
"What we build" + H2 "General contracting for people who plan to stay." on the left, supporting
paragraph right.

Four cards in a ruled grid (`repeat(auto-fit, minmax(280px, 1fr))`, `gap: 1px`, background
`rgba(22,24,26,0.14)`), each `min-height: 400px`, `background: paper`, hover → `paper-warm`:
4:3 image (hover `scale(1.05)` over `0.7s`), `01`–`04` index in muted caps, title, body, and a
bottom-anchored "Price this →" link to `#estimate`.

1. **Kitchens & Bathrooms** — open-concept kitchens, spa-inspired baths.
2. **Whole-Home Renovation** — dated house to elegant, energy-efficient home.
3. **Condo & Strata Work** — strata paperwork, elevator bookings, noise windows.
4. **Additions & Custom Builds** — basements, laneway homes, multi-unit, design-build.

### 7. Editorial / why-us
`paper-warm` band, two columns `auto-fit minmax(min(100%, 400px), 1fr)`.

Left: 6:5 image that clip-wipes open on scroll, with a `ink-panel` plaque overlapping its
bottom-right corner (`padding: 26px 30px; max-width: 260px`) reading "Craftmanship" (Newsreader,
30px) over "meets care" (`sage` micro caps) — lifted from their own site's closing line.

Right: kicker "Why homeowners choose us", H2 "The part most contractors get wrong is the middle.",
a paragraph, then four ruled rows in a `26px 1fr` grid with a `fir` `✓`: **Transparent quotes.** /
**Permits & strata, handled.** / **One point of contact.** / **Warrantied workmanship.** — each
with a supporting clause. Then an `ink` CTA "Start with a free consult →" (magnetic).

### 8. Projects — `#projects`
`ink-panel` band. Header row: kicker "Selected work" + H2 "Recent Metro Vancouver projects",
with an underlined "Discuss a project" link right-aligned (`white-space: nowrap`).

Four tiles in a wrapping flex row (`gap: clamp(18px, 2vw, 28px)`): two wide (`flex: 1.7 1 420px`,
3:2, `min-height: 300px`) and two tall (`flex: 1 1 280px`, 8:9), arranged wide → tall → tall → wide.
Each: image (hover `scale(1.04)` over `0.9s`), top-to-bottom scrim, and bottom-anchored text —
`sage` micro-caps location, `24–32px` 300-weight title, one-line description. All link to `#estimate`.

1. **Bathroom Renovation** — Vancouver Condo
2. **Kitchen Remodel** — Metro Vancouver
3. **Full Home Renovation** — Metro Vancouver
4. **Multi-Unit Custom Build** — Custom — The Maple

In production these should link to the real project detail pages on their site.

### 9. Testimonial
`paper`, centered, `max-width: 900px`. `fir` `★★★★★` at `0.3em` tracking, then the pull quote in
Newsreader 300 with curly quotes, then attribution in muted caps: "Homeowner · Full-home
renovation, Richmond". **Replace with a real, attributed review before launch** — ideally pulled
live from Google reviews.

### 10. Process — `#process`
`paper-warm` band. Header: kicker "How it goes" + H2 "Nine steps, no guesswork" + supporting line.

Tab row over a `1px` bottom border: `01 · Planning`, `02 · Installation`, `03 · Completion`,
`12.5px` uppercase `0.1em`, `white-space: nowrap`, `margin-right: 26px`, each with a `2px` bottom
border — `fir` + `ink` text when active, transparent + `rgba(22,24,26,0.72)` when not.

Panel below: three columns (`auto-fit minmax(270px, 1fr)`, `gap: clamp(24px, 3vw, 48px)`), each
with a Newsreader `46px` `fir` numeral, a `21px`/500 title, and a paragraph. Panels cross-fade
(`nfFade`, 0.4s) on tab change. Steps 01–09: Thorough consultation, Transparent quote, Material
selection / Preparation & permits, Professional execution, Quality inspections / Full cleanup,
Final walkthrough, Post-project support. (Content is adapted from their existing process copy.)

### 11. Service areas — `#areas`
Two columns `auto-fit minmax(min(100%, 380px), 1fr)`. Left: kicker "Service area", H2 "We work
across Metro Vancouver", a paragraph naming their Richmond address, and an underlined
"Book a walkthrough →" phone link (`nowrap`).

Right: eight cells in a ruled grid (`auto-fit minmax(190px, 1fr)`, `gap: 1px`, `1px` outer border),
`padding: 24px 22px`, hover → `paper-warm`. Seven are city + qualifier (`19px` name over `12.5px`
muted caps): Vancouver (Full service), Richmond (Home base), Burnaby, Surrey, Delta (Multi-unit
builds), White Rock, Tsawwassen (& Ladner). The eighth is an `ink-panel` cell: "Not sure if you're
in range? **Ask us**" with a `sage` link to `#estimate`.

For SEO, each city cell should link to its existing service-area page on their site.

### 12. FAQ — `#faq`
`paper-warm` band, `max-width: 1100px`, centered header (kicker "Before you call" + H2 "Straight
answers"). Four ruled accordion rows; trigger is a full-width flex row, `padding: 26px 0`, label
`clamp(17px, 1.6vw, 21px)`/400 left, `20px` `fir` `+` / `−` right. Answers `16px`/300,
`max-width: 70ch`, fade in. **First row open by default.** Only one open at a time; clicking the
open row closes it.

1. Is the estimate really free?
2. Do you handle permits and strata approvals?
3. Can the price change once work starts?
4. Is your work warrantied?

Add `FAQPage` JSON-LD schema in production.

### 13. Closing CTA
`ink-panel` band with the condo photo at `opacity: 0.3` and a left-to-right scrim. Two columns
(`auto-fit minmax(min(100%, 300px), 1fr)`), `align-items: center`. Left: `sage` kicker "Taking
projects for the next season", H2 "Let's talk about / your home." (hard break), paragraph.
Right (`min-width: 260px`, stacked, `gap: 14px`): a `paper` phone block ("Call now" micro caps over
`22px` number, magnetic, hover → `sage`) and an outlined "Get free estimate" block linking to `#estimate`.

### 14. Footer
`ink`, `padding: clamp(56px, 6vw, 88px) 28px 0`. Five columns (`auto-fit minmax(210px, 1fr)`, `gap: 44px`):

1. Logo at `74px` + the company blurb from their site.
2. **Contact** — phone (`paper`), `info@noblefirhomes.ca`, "8900 River Rd, Richmond BC".
3. **Services** — four anchor links.
4. **Company** — Projects, Our process, Service areas, FAQ.
5. **Renovation notes** — newsletter blurb + an underline-only email input with a `sage`
   "Subscribe" button that becomes "Subscribed ✓".

Column headings are `sage` micro caps. Bottom bar above a `1px` border: copyright / licensing line
left, four social text links right (Instagram, Facebook, LinkedIn, Pinterest — real URLs are in the file).

### 15. Sticky call bar
`position: sticky; bottom: 0; z-index: 70`, `fir` background, two equal links split by a `1px`
divider: "Call 778-686-0311" and "Free estimate". Hover → `rgba(255,252,250,0.1)`.
This is the single biggest mobile conversion lever — keep it.

### 16. Scroll progress rail
`position: fixed; top: 0; height: 2px; z-index: 90; pointer-events: none`, `sage` fill whose width
tracks `scrollY / (scrollHeight - innerHeight)`.

---

## Interactions & Behavior

All motion is suppressed under `prefers-reduced-motion: reduce` — the prototype both bails out of
the JS motion setup entirely and clamps animation/transition durations to `0.01ms` via a media query.
**Preserve this.**

### Entrance (CSS keyframes)
| Name | From → To | Duration / easing |
|---|---|---|
| `nfRise` | `opacity 0, translateY(18px)` → none | 0.9–1s `cubic-bezier(0.22,1,0.36,1)` |
| `nfFade` | `opacity 0 → 1` | 0.3–0.5s |
| `nfLine` | `scaleX(0) → scaleX(1)`, origin left | 0.8s `cubic-bezier(0.22,1,0.36,1)` |
| `nfLift` | `opacity 0, translateY(105%)` → none | 1.1s `cubic-bezier(0.19,1,0.22,1)` |
| `nfMarquee` | `translateX(0) → translateX(-50%)` | 42s linear infinite |

### Scroll reveals (IntersectionObserver)
Targets: `[data-reveal]`, all `h2`, all `blockquote`. On setup each is hidden
(`opacity: 0` plus `translateY(26px)`, or `clip-path: inset(0 0 100% 0)` + `scale(1.06)` for
`data-reveal="clip"`), given `transition-duration` 0.95s (1.25s for clips) with
`cubic-bezier(0.19,1,0.22,1)`, and a stagger delay of `min(indexWithinParent, 5) × 0.075s`.
Observer: `rootMargin: "0px 0px -12% 0px"`, `threshold: 0.12`.

**Critical:** there must be a safety-net sweep in the scroll loop that force-reveals any target
whose `rect.bottom < innerHeight * 0.9`, instantly (no transition) when it is already fully above
the viewport. Without it, anchor jumps and restored scroll positions leave whole sections
permanently blank. If you implement reveals with a library, make sure it has the equivalent
behaviour, and prefer a CSS-only approach (`animation-timeline: view()` where support allows)
with a no-JS fallback that leaves content visible.

### Count-up
`[data-count]` numerals animate `0 → target` over 1.4s with cubic ease-out (`1 - (1-p)³`) when 60%
visible, once. Decimal precision follows the target (`5.0` keeps one decimal); `%` suffix is
preserved; the `sage` child span (`+`, `★`) must be re-appended after each text write.

### Parallax
`[data-parallax]` images translate on the Y axis, derived from the **host section's progress through
the viewport** (`p = (innerHeight - rect.top) / (rect.height + innerHeight)`, clamped 0–1) as
`offset = cap × (1 - 2p)`, where `cap = (imageHeight - hostHeight) / 2`. Offset resets to `0` when
the section is off-screen. Hero image rate `0.22`, closing-CTA `0.14`; both are sized at `126%`
height with `-13%` offset so there is real overhang. **The clamp is the important part** — an
unclamped transform exposes bare section background at the edges.

### Scroll loop architecture
Parallax, progress rail, header state and the reveal sweep all run in **one self-scheduling
`requestAnimationFrame` ticker**, each frame wrapped in `try/catch`, and additionally driven by
`scroll` (passive), `resize` and `visibilitychange`. Do **not** gate it behind an
`if (!rafId)` gate keyed off the scroll event — if a frame never fires (hidden or throttled frame)
that latches and the entire loop freezes at stale values. In a React codebase this is one effect
with a full teardown.

### Magnetic CTAs
`[data-magnet]` elements translate toward the cursor on `mousemove`:
`translate(dx × 9px, dy × 6px)` where `dx/dy` are the cursor's normalised offset from the element
centre, with `transition: transform 0.12s linear` while tracking and
`0.6s cubic-bezier(0.19,1,0.22,1)` on `mouseleave` back to `none`. Applied to the hero primary CTA,
the why-us CTA and the closing phone block. Pointer-fine devices only.

### Cursor-follow project badge
A fixed pill (`999px`, `paper` on `ink` text, `13px 20px`, `11.5px` uppercase `0.14em`,
`0 14px 34px -14px rgba(0,0,0,0.6)`) reading "View project", appended to `body`, `z-index: 85`,
`pointer-events: none`. On `[data-project]` enter: `opacity 0 → 1`, `scale(0.4) → scale(1)`
(`0.45s cubic-bezier(0.19,1,0.22,1)`). Position follows the cursor via rAF-throttled `left/top` with
`translate(-50%, -50%)`. On leave it scales back down and fades out. Skip on touch devices.

### Hover states (summary)
- Nav links: color to `paper` + `sage` underline border.
- Buttons: `paper ⇄ sage`, `ink → fir`, `fir → ink`; outlined → border `paper` + faint fill.
- Service cards: background `paper → paper-warm`, image `scale(1.05)` / `0.7s`.
- Project tiles: image `scale(1.04)` / `0.9s` + the badge.
- Area cells: background `paper → paper-warm` / `0.3s`.
- Marquee: pauses.

### Responsive behaviour
The prototype is fluid with **no media queries** — every multi-column grid uses
`repeat(auto-fit, minmax(min(100%, Npx), 1fr))` and the project tiles use flex with
`flex-basis` floors, so everything collapses to one column on narrow viewports. Type scales with
`clamp()`. You may of course use breakpoints in production; the intended collapse order is:
hero → form stacks under copy; services 4 → 2 → 1; projects 2 → 1; footer 5 → 2 → 1.
Tap targets are at or above 44px in the sticky bar, buttons and accordion triggers.

---

## State Management

Component state in the prototype (all local; nothing is persisted):

| Key | Type | Purpose |
|---|---|---|
| `step` | `1 \| 2` | Estimate form step |
| `service` | string | Chosen project type (`""` until picked; defaults to `"Renovation"` on Continue) |
| `first`, `last`, `email`, `phone`, `area` | string | Form fields |
| `sent` | boolean | Swaps the card to the success state |
| `stage` | `"planning" \| "install" \| "done"` | Active process tab |
| `faq` | number | Index of the open FAQ (`0` on load, `-1` = all closed) |
| `subEmail` | string | Footer newsletter input |
| `subbed` | boolean | Newsletter button label |

Two configuration props, both exposed as design-time toggles:

- `oneStepForm` (boolean, default `false`) — collapses the estimate form to a single step: both
  panels render together, the Continue and Back controls disappear, the progress bar pins at 100%
  and the step label becomes "Free estimate request". **Worth A/B testing** — two-step usually wins
  on total submissions, one-step on high-intent traffic.
- `showCallBar` (boolean, default `true`) — the sticky bottom call bar.

Production additions needed: real form submission (server action / API route), field validation and
error states, a loading state on submit, spam protection, and analytics events for
`estimate_start`, `estimate_step_2`, `estimate_submit` and `phone_click`.

---

## Assets

All assets in the prototype are hot-linked from the client's existing Wix CDN
(`static.wixstatic.com`). **These must be downloaded, re-exported and self-hosted** in the new
build — hot-linking Wix is fragile and slow.

| Asset | Source URL (in the HTML) | Usage |
|---|---|---|
| Logo (white, transparent) | `71ef83_46bafb72928f414ab089b1e68a3b05e1~mv2.webp` | Header (56px, 42px scrolled), footer (74px) |
| Kitchen, front view | `71ef83_569513e235664c91a9efd4303963ee11~mv2.png` | Hero background |
| Kitchen renovation by NFH | `71ef83_676772f171944a449b08510ea13761db~mv2.jpg` | Service card 1, project tile 2 |
| Full renovation Vancouver | `71ef83_3abf36655af04898bcd6bf7aa0c80954~mv2.jpg` | Service card 2, project tile 3 |
| Condo renovation Vancouver | `71ef83_66c0438feb28426d8f8cd916efbb4bc8~mv2.webp` | Service card 3, closing CTA background |
| Multi-home remodel | `71ef83_9fb885efa8bf439da214744ddd0edd05~mv2.jpg` | Service card 4, project tile 4 |
| Bathroom renovation | `71ef83_48598fb1ee7a41a9becb001cf9f2d874~mv2.jpg` | Project tile 1 |
| Interior / staircase | `71ef83_0239e4f39c5b4faa964a3fc969bfc372~mv2.jpg` | Editorial section |

Ask the client for the original full-resolution files, plus a vector (SVG) logo — only a raster
version is published. Serve modern formats (AVIF/WebP) at responsive widths; the hero should be
preloaded, everything below the fold lazy-loaded. Alt text in the prototype is written for SEO and
should be carried over (and improved where it's keyword-stuffed).

Fonts: `Jost` and `Newsreader`, both Google Fonts — self-host the subsets in production
(`preconnect` + `display=swap` in the prototype). Confirm the client's real brand fonts first.

No icon library is used. The only glyphs are text characters: `→ ✓ ★ ✦ − + /`. Keep it that way —
the design has no illustrative SVG.

---

## Also worth doing in the real build

Not part of the visual design, but this is a lead-gen site for a local contractor:

- `LocalBusiness` + `FAQPage` JSON-LD; the existing page's title/meta/canonical are worth carrying over.
- Semantic heading order (the current Wix site uses `h2` for nearly everything — this redesign uses one `h1` and real section `h2`s).
- `tel:` links everywhere the number appears; `aria-expanded` on the FAQ triggers and process tabs; visible focus rings (the prototype removes the default outline on inputs — replace it with a `fir` focus ring rather than nothing).
- Keyboard support for the accordion and tabs.
- Core Web Vitals: the hero is the LCP element, so preload it and avoid layout shift from the web fonts.

## Files

- `Noble Fir Homes.dc.html` — the full homepage design reference (markup + behaviour). Open it in a browser to see the live prototype including all motion.

Source site for content and assets: https://www.noblefir.ca/
